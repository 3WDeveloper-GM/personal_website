<template>
   <div ref="header">
      <svg width="985" height="520" viewBox="0 0 985 520" fill="none" xmlns="http://www.w3.org/2000/svg">
         <g id="Frame 1">
            <rect width="985" height="520" fill="#2E3440" />
            <g class="content">
               <rect class="fades-out" y="377" width="162" height="32" fill="#D8DEE9" />
               <rect class="slider" x="162" y="377" width="730" height="32" fill="url(#paint0_linear_1_2)" />
               <rect class="slider" x="892.5" y="377.355" width="91.5498" height="31.936" fill="#4C566A" />
               <text class="fades-out" id="MATLAB" fill="black" xml:space="preserve" style="white-space: pre"
                  font-family="Inter" font-size="13.5063" letter-spacing="0em">
                  <tspan x="53.6425" y="398.788">MATLAB</tspan>
               </text>
            </g>
            <g class="content">
               <rect class="fades-out" x="0.5" y="319.355" width="162" height="32" fill="#D8DEE9" />
               <rect class="slider" x="162.5" y="319.355" width="518" height="32" fill="url(#paint1_linear_1_2)" />
               <rect class="slider" x="680.5" y="319.355" width="304" height="32" fill="#4C566A" />
               <text class="fades-out" id="R" fill="black" xml:space="preserve" style="white-space: pre"
                  font-family="Inter" font-size="13.5063" letter-spacing="0em">
                  <tspan x="76.7179" y="340.239">R</tspan>
               </text>
            </g>
            <g class="content">
               <rect class="fades-out" x="0.5" y="260.355" width="162" height="32" fill="#D8DEE9" />
               <rect class="slider" x="162.5" y="260.355" width="581" height="32" fill="url(#paint2_linear_1_2)" />
               <rect class="slider" x="743.5" y="260.355" width="241" height="32" fill="#4C566A" />
               <text class="fades-out" id="Javascript" fill="black" xml:space="preserve" style="white-space: pre"
                  font-family="Inter" font-size="13.5063" letter-spacing="0em">
                  <tspan x="48.2611" y="281.69">Javascript</tspan>
               </text>
            </g>
            <g class="content">
               <rect class="fades-out" x="-0.5" y="202.355" width="163" height="32" fill="#D8DEE9" />
               <rect class="slider" x="162.5" y="202.355" width="559" height="32" fill="url(#paint3_linear_1_2)" />
               <rect class="slider" x="721.5" y="202.355" width="263" height="32" fill="#4C566A" />
               <text class="fades-out" id="Go" fill="black" xml:space="preserve" style="white-space: pre"
                  font-family="Inter" font-size="13.5063" letter-spacing="0em">
                  <tspan x="71.9894" y="223.14">Go</tspan>
               </text>
            </g>
            <g class="content">
               <rect class="fades-out" x="0.5" y="143.355" width="162" height="32" fill="#D8DEE9" />
               <rect class="slider" x="162.5" y="143.355" width="682" height="32" fill="url(#paint4_linear_1_2)" />
               <rect class="slider" x="844.5" y="143.355" width="140" height="32" fill="#4C566A" />
               <text class="fades-out" id="Python" fill="black" xml:space="preserve" style="white-space: pre"
                  font-family="Inter" font-size="13.5063" letter-spacing="0em">
                  <tspan x="58.4897" y="164.549">Python</tspan>
               </text>
            </g>
            <g class="content">
               <rect class="fades-out" y="85" width="162" height="32" fill="#D8DEE9" />
               <rect class="slider" x="162" y="85" width="731" height="32" fill="url(#paint5_linear_1_2)" />
               <rect class="slider" x="892.5" y="85.3547" width="92" height="32" fill="#4C566A" />
               <text class="fades-out" id="Wolfram Mathematica" fill="black" xml:space="preserve"
                  style="white-space: pre" font-family="Inter" font-size="13.5063" letter-spacing="0em">
                  <tspan x="2.34489" y="105.879"> Wolfram Mathematica</tspan>
               </text>
            </g>
         </g>
         <defs>
            <linearGradient id="paint0_linear_1_2" x1="162" y1="393" x2="892" y2="393" gradientUnits="userSpaceOnUse">
               <stop stop-color="#5E81AC" />
               <stop offset="0.502468" stop-color="#81A1C1" />
               <stop offset="1" stop-color="#88C0D0" />
            </linearGradient>
            <linearGradient id="paint1_linear_1_2" x1="162.5" y1="335.355" x2="680.5" y2="335.355"
               gradientUnits="userSpaceOnUse">
               <stop stop-color="#5E81AC" />
               <stop offset="0.502468" stop-color="#81A1C1" />
               <stop offset="1" stop-color="#88C0D0" />
            </linearGradient>
            <linearGradient id="paint2_linear_1_2" x1="162.5" y1="276.355" x2="743.5" y2="276.355"
               gradientUnits="userSpaceOnUse">
               <stop stop-color="#5E81AC" />
               <stop offset="0.502468" stop-color="#81A1C1" />
               <stop offset="1" stop-color="#88C0D0" />
            </linearGradient>
            <linearGradient id="paint3_linear_1_2" x1="162.5" y1="218.355" x2="721.5" y2="218.355"
               gradientUnits="userSpaceOnUse">
               <stop stop-color="#5E81AC" />
               <stop offset="0.502468" stop-color="#81A1C1" />
               <stop offset="1" stop-color="#88C0D0" />
            </linearGradient>
            <linearGradient id="paint4_linear_1_2" x1="162.5" y1="159.355" x2="844.5" y2="159.355"
               gradientUnits="userSpaceOnUse">
               <stop stop-color="#5E81AC" />
               <stop offset="0.502468" stop-color="#81A1C1" />
               <stop offset="1" stop-color="#88C0D0" />
            </linearGradient>
            <linearGradient id="paint5_linear_1_2" x1="162" y1="101" x2="893" y2="101" gradientUnits="userSpaceOnUse">
               <stop stop-color="#5E81AC" />
               <stop offset="0.502468" stop-color="#81A1C1" />
               <stop offset="1" stop-color="#88C0D0" />
            </linearGradient>
         </defs>
      </svg>
   </div>
</template>

<script>

import { setDelayTimes } from '../utils/utils'

export default {
   mounted() {
      this.addDelayTimes()
   },
   methods: {
      addDelayTimes() {
         let element = this.$refs.header.getElementsByClassName("content")
         let offset = 500
         let delayStep = 500
         let elementNumber = element.length
         for (let index = 1; index <= elementNumber; index++) {
            let newOffset = setDelayTimes(element[elementNumber - index].children, delayStep, offset)
            offset = newOffset
         }
      }
   }
}
</script>

<style lang="scss" scoped>
.fades-out {
   opacity: 0;
   animation-name: fadein;
   animation-duration: 1s;
   animation-delay: 5s;
   animation-fill-mode: forwards;
   animation-timing-function: ease-in-out;
}

@keyframes fadein {
   from {
      opacity: 0;
      transform: translateY(-50px);
   }

   to {
      opacity: 1;
      transform: translateY(0px);
   }
}

.slider {
   opacity: 0;
   width: 0;
   animation-name: slide;
   animation-duration: 3s;
   animation-delay: 5s;
   animation-fill-mode: forwards;
   animation-timing-function: ease-in-out;
}

@keyframes slide {
   from {
      opacity: 0;
      width: 0;
   }

   to {
      opacity: 1;
      width: 100%;
   }
}
</style>